import React, { useState } from 'react';
import { Menu, X, Sparkles } from 'lucide-react';
export default function Navbar() {
  const [open, setOpen] = useState(false);
  const links = [['About', '#about'], ['Skills', '#skills'], ['Projects', '#projects'], ['Contact', '#contact']];
  return <header className="navbar"><a className="brand" href="#home"><span className="brand-mark"><Sparkles size={17}/></span> wajid<span className="brand-dot">.</span></a>
    <button className="mobile-toggle" aria-label="Toggle navigation" onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button>
    <nav className={open ? 'nav-links open' : 'nav-links'}>{links.map(([label, href]) => <a key={href} href={href} onClick={() => setOpen(false)}>{label}</a>)}<a className="nav-cta" href="#contact" onClick={() => setOpen(false)}>Let's talk <span>↗</span></a></nav>
  </header>;
}
