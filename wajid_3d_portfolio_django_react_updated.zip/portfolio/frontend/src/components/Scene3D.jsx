import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Float, MeshDistortMaterial, OrbitControls, Stars, Sphere, Torus, Icosahedron } from '@react-three/drei';

function Core() {
  return <Float speed={1.4} rotationIntensity={0.55} floatIntensity={0.8}>
    <Sphere args={[1.12, 64, 64]} scale={1.15}>
      <MeshDistortMaterial color="#8b5cf6" roughness={0.15} metalness={0.72} distort={0.32} speed={2.2} emissive="#32116e" emissiveIntensity={0.45} />
    </Sphere>
    <Torus args={[1.62, 0.012, 16, 180]} rotation={[1.08, 0.3, 0.25]}>
      <meshStandardMaterial color="#63e6ff" emissive="#1e9ec4" emissiveIntensity={2.3} metalness={0.8} />
    </Torus>
    <Torus args={[1.82, 0.008, 12, 180]} rotation={[0.15, 1.12, 0.55]}>
      <meshStandardMaterial color="#c4b5fd" emissive="#7c3aed" emissiveIntensity={1.6} />
    </Torus>
    <Float speed={2} rotationIntensity={1} floatIntensity={1.4}>
      <Icosahedron args={[0.17, 1]} position={[1.65, 0.65, 0.25]}>
        <meshStandardMaterial color="#62e9ff" metalness={0.65} roughness={0.18} emissive="#146c8c" emissiveIntensity={1.2} />
      </Icosahedron>
    </Float>
  </Float>;
}
export default function Scene3D() {
  return <div className="scene3d" aria-label="Animated abstract 3D orb">
    <Canvas camera={{ position: [0, 0, 5.6], fov: 42 }} dpr={[1, 1.7]}>
      <Suspense fallback={null}>
        <ambientLight intensity={0.8} />
        <pointLight position={[4, 3, 4]} intensity={24} color="#b6a0ff" />
        <pointLight position={[-4, -2, 2]} intensity={16} color="#36d9ff" />
        <Stars radius={70} depth={35} count={1300} factor={2.4} saturation={0} fade speed={0.5} />
        <Core />
        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.65} maxPolarAngle={Math.PI / 1.7} minPolarAngle={Math.PI / 2.7} />
      </Suspense>
    </Canvas>
  </div>;
}
