export const profile = {
  name: 'Wajid Ul Haq Alvi',
  firstName: 'Wajid',
  role: 'Python Developer & AI/ML Enthusiast',
  intro: 'I turn complex problems into elegant digital experiences.',
  about: 'I am a computer science graduate passionate about building useful web applications, data-driven products, and practical AI solutions. I enjoy taking an idea from a clear plan to a working, polished product.',
  email: 'wajidulhaq44@gmail.com',
  WhatsApp: '+923015381689',
  github: 'https://github.com/wajid12khan',
  linkedin: 'https://www.linkedin.com/in/wajid-ul-haq-333954288?utm_source=share_via&utm_content=profile&utm_medium=member_android',
  location: 'Hazara, Khyber Pakhtunkhwa, Pakistan',
  skills: ['Python', 'Django', 'REST APIs', 'React', 'JavaScript', 'SQL', 'Scikit-learn', 'TensorFlow', 'Pandas', 'Git & GitHub', 'Streamlit', 'Docker basics'],
};
export const fallbackProjects = [
  { id: 'churn', title: 'Customer Churn Prediction', description: 'An end-to-end machine learning workflow to identify customers at risk of leaving, with preprocessing and model evaluation.', technologies: ['Python', 'Scikit-learn', 'Pandas', 'Streamlit'], github_url: 'https://github.com/wajid12khan', live_url: '', featured: true },
  { id: 'fraud', title: 'Credit Card Fraud Detection', description: 'A classification project focused on imbalanced data, exploratory analysis, and practical fraud-risk predictions.', technologies: ['Python', 'Pandas', 'Scikit-learn', 'Plotly'], github_url: 'https://github.com/wajid12khan', live_url: '', featured: true },
  { id: 'school-ai', title: 'AI Learning Assistant', description: 'A concept for a learning assistant that answers questions from supplied educational materials and helps learners study.', technologies: ['Python', 'Django', 'RAG', 'LLMs'], github_url: 'https://github.com/wajid12khan', live_url: '', featured: false },
];
