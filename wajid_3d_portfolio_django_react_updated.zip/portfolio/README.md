# 3D Personal Portfolio — Django + React

A responsive personal portfolio starter with a React/Vite frontend, React Three Fiber 3D hero, and Django REST Framework backend.

## Requirements
- Python 3.10+
- Node.js 18+

## 1. Start the Django backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser  # optional, for Django admin
python manage.py runserver
```
Backend API: http://127.0.0.1:8000/api/portfolio/  
Admin: http://127.0.0.1:8000/admin/

## 2. Start the React frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL Vite prints (usually http://localhost:5173).

## Customize
- Edit `frontend/src/data.js` to change your name, role, social links, skills and fallback projects.
- Set your real GitHub, LinkedIn, email and resume link there.
- The frontend loads projects from Django and falls back to local sample projects if the API is unavailable.
- Add/edit projects in Django admin after creating a superuser.
- Contact form posts to Django and stores messages in the database. Configure SMTP before adding email notifications.

## Notes
This is a development starter, not a hardened production deployment. Before deploying, set `DEBUG=False`, configure `ALLOWED_HOSTS`, use environment variables for secrets, configure HTTPS and production database/static/media hosting, and add rate limiting/spam protection to the contact endpoint.
