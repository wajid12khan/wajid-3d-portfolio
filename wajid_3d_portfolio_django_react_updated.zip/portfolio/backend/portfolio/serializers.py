from rest_framework import serializers
from .models import Project, ContactMessage

class ProjectSerializer(serializers.ModelSerializer):
    technologies = serializers.SerializerMethodField()
    class Meta:
        model = Project
        fields = ["id", "title", "description", "tech_stack", "technologies", "github_url", "live_url", "featured"]
    def get_technologies(self, obj):
        return [item.strip() for item in obj.tech_stack.split(",") if item.strip()]

class ContactMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactMessage
        fields = ["id", "name", "email", "subject", "message", "created_at"]
        read_only_fields = ["id", "created_at"]
    def validate_name(self, value):
        value = value.strip()
        if len(value) < 2:
            raise serializers.ValidationError("Please enter a name with at least 2 characters.")
        return value
    def validate_message(self, value):
        value = value.strip()
        if len(value) < 10:
            raise serializers.ValidationError("Please enter a message with at least 10 characters.")
        return value
