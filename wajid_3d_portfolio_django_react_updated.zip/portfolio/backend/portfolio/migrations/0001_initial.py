from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(name='Project', fields=[('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('title', models.CharField(max_length=120)), ('description', models.TextField()), ('tech_stack', models.CharField(help_text='Comma-separated technologies', max_length=250)), ('github_url', models.URLField(blank=True)), ('live_url', models.URLField(blank=True)), ('featured', models.BooleanField(default=False)), ('created_at', models.DateTimeField(auto_now_add=True))], options={'ordering': ['-featured', '-created_at']}),
        migrations.CreateModel(name='ContactMessage', fields=[('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('name', models.CharField(max_length=100)), ('email', models.EmailField(max_length=254)), ('subject', models.CharField(blank=True, max_length=160)), ('message', models.TextField(max_length=5000)), ('created_at', models.DateTimeField(auto_now_add=True))]),
    ]
