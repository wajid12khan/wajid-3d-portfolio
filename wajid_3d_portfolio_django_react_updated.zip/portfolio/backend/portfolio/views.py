from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Project
from .serializers import ProjectSerializer, ContactMessageSerializer

class PortfolioView(APIView):
    def get(self, request):
        projects = ProjectSerializer(Project.objects.all(), many=True).data
        return Response({
            "profile": {
                "name": "Wajid Ul Haq Alvi",
                "headline": "Python Developer · AI/ML Enthusiast",
                "location": "Pakistan",
                "summary": "I build useful digital products by combining Python, thoughtful design, and practical AI.",
            },
            "projects": projects,
        })

class ContactCreateView(generics.CreateAPIView):
    serializer_class = ContactMessageSerializer
    queryset = ContactMessage.objects.all()
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": "Thanks! Your message has been received."}, status=status.HTTP_201_CREATED)
