from django.urls import path
from .views import PortfolioView, ContactCreateView
urlpatterns = [
    path("portfolio/", PortfolioView.as_view(), name="portfolio"),
    path("contact/", ContactCreateView.as_view(), name="contact"),
]
